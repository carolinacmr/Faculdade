//classe metoddo obkjeto messagem
package Bicicleta;

import javax.swing.JOptionPane;


public class NewMain {

   
    public static void main(String[] args) {
      
               
        Bike b1 = new Bike();
        b1.setCor("rosa");
        b1.setMarca("caloi");
        b1.setAno(2020);
        b1.setVelocidade(12);
        JOptionPane.showMessageDialog(null,"Cor "+b1.getCor()+"\nMarca " +b1.getMarca()+
                                       "\nAno "+ b1.getAno()+"\nVelocidade "+b1.getVelocidade()+"km");
        
        
    }
    
}
