
package Bicicleta;


public class Bike {
    //abstração real de uma bike com od atributos que eu quero
    //atributos da classe:
    String cor;
    String marca;
    int ano;
    int velocidade;

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }
    
    public int getVelocidade() {
        return velocidade;
    }

    public void setVelocidade(int velocidade) {
        this.velocidade = velocidade;
    }
    
      //metodos da classe
    //minusculo metodo maiusculo classe


//cria um metodo para velocidade atual do objeto
// freio    
}


